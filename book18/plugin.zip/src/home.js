function execute() {
    return Response.success([
        { title: "主页", input: "/", script: "up.js" }
    ]);
}
